package twitter;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import twitter4j.FilterQuery;
import twitter4j.StallWarning;
import twitter4j.Status;
import twitter4j.StatusDeletionNotice;
import twitter4j.StatusListener;
import twitter4j.TwitterStream;
import twitter4j.TwitterStreamFactory;
import twitter4j.User;
import twitter4j.conf.ConfigurationBuilder;

public class SimpleStream {
	
	public static void main(String args[]) throws IOException{
		ConfigurationBuilder cb = new ConfigurationBuilder();
		cb.setDebugEnabled(true);
		cb.setOAuthConsumerKey("pxFTx1bwYKc2xf46wJkHoROQF");
		cb.setOAuthConsumerSecret("8IRHOt5AuYoEJmSWsMDLenSRjIJvwJXwQGtjcSXVWIJtlAGUS5");
		cb.setOAuthAccessToken("2800523017-fgoIXo45OJaYhIgljmbVmlnKxoB4rVDpocZMoJp");
		cb.setOAuthAccessTokenSecret("nlxZ5xnqRxQD7zdiSNaKVgnRyubT5KUUkguPnsI9pfVrx");
		
		TwitterStream twitterStream	= new TwitterStreamFactory(cb.build()).getInstance(); 
		
		StatusListener listener = new StatusListener() {
			
			public int c = 0;
			@Override
			public void onStatus(Status status){
				User user = status.getUser();
				
				String file_name = "tweets.txt";
				WriteFile data = new WriteFile(file_name, true);
				
				String username = status.getUser().getScreenName();
				String language = user.getLang();
				if(language.equals("en")){
					try{
						data.writeToFile(username + "\n");}
					catch(IOException e){
						System.out.println("Error username");
					}
					String profileLocation = user.getLocation();
					try{
						data.writeToFile(profileLocation + "\n");
					}
					catch(IOException e){
						System.out.println("Error profileLocation");
					}
					long tweetId = status.getId();
					try{
						data.writeToFile(tweetId + "\n");
					}
					catch(IOException e){
						System.out.println("Error tweetId");
					}
					String content = status.getText();
					try{
						data.writeToFile(content + "\n");
					}
					catch(IOException e){
						System.out.println("Error content");
					}
					try{
						data.writeToFile("------------------------------------\n");
					}
					catch(IOException e){
						System.out.println("Error file");
					}
				
					c = c + 1;
				}
				System.out.println("Tweet: " + c);
				//if(c == 10000){
				//	System.exit(0);;
				//}
			}

			@Override
			public void onException(Exception arg0) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onDeletionNotice(StatusDeletionNotice arg0) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onScrubGeo(long arg0, long arg1) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onStallWarning(StallWarning arg0) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onTrackLimitationNotice(int arg0) {
				// TODO Auto-generated method stub
				
			}
		};
		
		FilterQuery fq = new FilterQuery();
		String hashtags = "#donaldtrump #trump #maga #trumpcare #usa #hillaryclinton #clinton #barackobama #obama #obamacare #america #news #killthebill #fbf #tcot #yemen @realDonaldTrump @HillaryClinton @BarackObama @youngdems4trump @veteran4trump";
		String[] tableHashtags = hashtags.split(" "); 
		String keywords[] = tableHashtags;
		fq.track(keywords);
		twitterStream.addListener(listener);
		twitterStream.filter(fq);
	}
}
